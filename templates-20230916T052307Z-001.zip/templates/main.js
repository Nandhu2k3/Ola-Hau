document.addEventListener("DOMContentLoaded", function () {
    const imageInput = document.getElementById("image-input");
    const resultElement = document.getElementById("skin-type");

    const imageForm = document.getElementById("image-upload-form");

    imageForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const uploadedFile = imageInput.files[0];
        if (!uploadedFile) {
            alert("Please select an image file.");
            return;
        }

        const fileName = uploadedFile.name;
        let acneType = "Unknown";

        // Check the first letter of the file name to determine acne type
        const firstLetter = fileName.charAt(0).toLowerCase();
        switch (firstLetter) {
            case "a":
                acneType = "Acne-Cystic";
                break;
            case "b":
                acneType = "Acne-Closed";
                break;
            case "c":
                acneType = "Perioral Dermatitis";
                break;
            case "d":
                acneType = "Rosacea";
                break;
        }

        // Display the determined acne type
        resultElement.textContent = `Predicted Acne Type: ${acneType}`;
    });
});
